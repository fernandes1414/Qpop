// var navbarLinks = document.querySelectorAll('.');


// navbarLinks.forEach(function (link) {
//     link.addEventListener('click', function (event) {

//         var target = document.querySelector(link.getAttribute('href'));


//         event.preventDefault();


//         window.scrollTo({
//             top: target.offsetTop,
//             behavior: 'smooth'
//         });
//     });
// });